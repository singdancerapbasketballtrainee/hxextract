package di

import "testing"

// app启动单元测试
func AppStartTest(T *testing.T) {
	InitApp()
}
